<?php


// Include the authentication script if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'config/loginauth.php'; // Include the authentication script
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Title -->
    <title>Login</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Favicon -->
      <!-- Favicon -->
    <link rel="shortcut icon" href="public/img/favicon.ico">
    <!-- Add your favicon link here if you have one -->

    <!-- Template -->
    <link rel="stylesheet" href="public/graindashboard/css/graindashboard.css">
    <style>
        .login-container {
            display: flex;
            height: 100vh;
            align-items: center;
            justify-content: center;
        }
        .left-column {
            background-color: #f7f7f7;
            padding: 40px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .left-column img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
        .right-column {
            padding: 40px;
        }
    </style>
</head>
<body>
    <main class="main">
        <div class="container-fluid login-container">
            <div class="row w-100">
                <!-- Left column for logo and text -->
                <div class="col-md-6 left-column text-center">
                    <img src="public/img/logo11.png" alt="Logo">
                    <h1>Welcome to RMO Revenue Collection and Report System</h1>
                    <p>Please sign in to continue</p>
                </div>

                <!-- Right column for login form -->
                <div class="col-md-6 right-column">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title" align="center">Login</h4>
                            <form method="post">
                                <div class="form-group">
                                    <label for="email">E-mail Address</label>
                                    <input id="email" type="email" class="form-control" name="email" required="" autofocus="">
                                </div>

                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input id="password" type="password" class="form-control" name="password" required="">
                                    <div class="text-right">
                                        <a href="password-reset.html" class="small">Forgot Your Password?</a>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="form-check position-relative mb-2">
                                        <input type="checkbox" class="form-check-input d-none" id="remember" name="remember">
                                        <label class="checkbox checkbox-xxs form-check-label ml-1" for="remember" data-icon="&#xe936">Remember Me</label>
                                    </div>
                                </div>

                                <div class="form-group no-margin">
                                    <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                                </div>
                            </form>
                            <?php
                            // Display error messages if any
                            if (isset($_GET['error'])) {
                                echo '<div class="alert alert-danger">' . htmlspecialchars($_GET['error']) . '</div>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="public/graindashboard/js/graindashboard.js"></script>
    <script src="public/graindashboard/js/graindashboard.vendor.js"></script>
</body>
</html>
