<?php
session_start(); // Start the session

// Disable browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Include the config file for database connection
include 'config/config.php';

// Check if the user is logged in and is an Admin
if (!isset($_SESSION['user_id']) || $_SESSION['roleid'] != 1) {
    // If not logged in or not an Admin, redirect to the login page or logout
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

$month_id = isset($_POST['month_id']) ? $_POST['month_id'] : null;

if ($month_id) {
    // SQL query to retrieve the data based on the selected month
    $query = "
    SELECT 
        RMO_OFFICE.office_name AS rmo_office_name, 
        MONTHS.month_name, 
        MONTHS.year, 
        YEARLY_TARGETS.target, 
        DATA.total_collected, 
        DATA.PERCENTAGE_COLLECTED AS percentage_balance, 
        DATA.BALANCE 
    FROM 
        DATA 
    INNER JOIN 
        RMO_OFFICE ON DATA.rmo_id = RMO_OFFICE.id 
    INNER JOIN 
        MONTHS ON DATA.month_id = MONTHS.id 
    INNER JOIN 
        YEARLY_TARGETS ON DATA.rmo_id = YEARLY_TARGETS.rmo_id AND MONTHS.year = YEARLY_TARGETS.year
    WHERE 
        DATA.month_id = ?
    ";

    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $month_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

$sn = 1; // Serial number for the table rows
?>


<!DOCTYPE html>
<html lang="en">
<head>

 <!-- JavaScript to disable back/forward navigation -->
 <script type="text/javascript">
        // Prevent navigating back
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
            history.go(1);
        };
    </script>

    <!-- Title -->
    <title>Admin Dashboard RMO</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Favicon -->
    <link rel="shortcut icon" href="public/img/favicon.ico">

    <!-- DEMO CHARTS -->
    <link rel="stylesheet" href="public/demo/chartist.css">
    <link rel="stylesheet" href="public/demo/chartist-plugin-tooltip.css">

    <!-- Template -->
    <link rel="stylesheet" href="public/graindashboard/css/graindashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="has-sidebar has-fixed-sidebar-and-header">
<header class="header bg-body">
    <nav class="navbar flex-nowrap p-0">
        <div class="navbar-brand-wrapper d-flex align-items-center col-auto">
            <!-- Logo For Mobile View -->
            <a class="navbar-brand navbar-brand-mobile" href="/">
                <img class="img-fluid w-100" src="public/img/logo-mini.png" alt="Graindashboard">
            </a>
            <!-- End Logo For Mobile View -->

            <!-- Logo For Desktop View -->
            <a class="navbar-brand navbar-brand-desktop" href="/">
               
                <img class="side-nav-hide-on-closed" src="public/img/kalogo.png" style="width: auto; height: 60px;">
            </a>
            <!-- End Logo For Desktop View -->
        </div>

        <div class="header-content col px-md-3">
            <div class="d-flex align-items-center">
                <!-- Side Nav Toggle -->
                <a class="js-side-nav header-invoker d-flex mr-md-2" href="#"
                    data-close-invoker="#sidebarClose"
                    data-target="#sidebar"
                    data-target-wrapper="body">
                    <i class="gd-align-left"></i>
                </a>
                <!-- End Side Nav Toggle -->

                <!-- User Notifications -->
                <div class="dropdown ml-auto">
                    
                </div>
                <!-- End User Notifications -->
                <!-- User Avatar -->
                <div class="dropdown mx-3 dropdown ml-2">
                    <a id="profileMenuInvoker" class="header-complex-invoker" href="#" aria-controls="profileMenu" aria-haspopup="true" aria-expanded="false" data-unfold-event="click" data-unfold-target="#profileMenu" data-unfold-type="css-animation" data-unfold-duration="300" data-unfold-animation-in="fadeIn" data-unfold-animation-out="fadeOut">
        
                        <span class="d-none d-md-block">RMO - Admin</span>
                        <i class="gd-angle-down d-none d-md-block ml-2"></i>
                    </a>

                    <ul id="profileMenu" class="unfold unfold-user unfold-light unfold-top unfold-centered position-absolute pt-2 pb-1 mt-4 unfold-css-animation unfold-hidden fadeOut" aria-labelledby="profileMenuInvoker" style="animation-duration: 300ms;">
                        <li class="unfold-item">
                            <a class="unfold-link d-flex align-items-center text-nowrap" href="edit-profile.php">
                    <span class="unfold-item-icon mr-3">
                      <i class="gd-user"></i>
                    </span>
                                My Profile
                            </a>
                        </li>
                        <li class="unfold-item unfold-item-has-divider">
                            <a class="unfold-link d-flex align-items-center text-nowrap" href="logout.php">
                    <span class="unfold-item-icon mr-3">
                      <i class="gd-power-off"></i>
                    </span>
                                Sign Out
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- End User Avatar -->
            </div>
        </div>
    </nav>
</header>
<!-- End Header -->

<main class="main">
    <!-- Sidebar Nav -->
    <aside id="sidebar" class="js-custom-scroll side-nav">
    <ul id="sideNav" class="side-nav-menu side-nav-menu-top-level mb-0">
        <!-- Title -->
        <li class="sidebar-heading h6">Dashboard</li>
        <!-- End Title -->

        <!-- Dashboard -->
        <li class="side-nav-menu-item active">
            <a class="side-nav-menu-link media align-items-center" href="admin_dashboard.php">
              <span class="side-nav-menu-icon d-flex mr-3">
                <i class="gd-dashboard"></i>
              </span>
                <span class="side-nav-fadeout-on-closed media-body">Dashboard</span>
            </a>
        </li>
        <!-- End Dashboard -->

        <!-- Title -->
    <hr>
        <!-- End Title -->

        <!-- Users -->
        <li class="side-nav-menu-item side-nav-has-menu">
            <a class="side-nav-menu-link media align-items-center" href="#"
               data-target="#subUsers">
              <span class="side-nav-menu-icon d-flex mr-3">
                <i class="gd-user"></i>
              </span>
                <span class="side-nav-fadeout-on-closed media-body">Users</span>
                <span class="side-nav-control-icon d-flex">
              <i class="gd-angle-right side-nav-fadeout-on-closed"></i>
            </span>
                <span class="side-nav__indicator side-nav-fadeout-on-closed"></span>
            </a>

            <!-- Users: subUsers -->
            <ul id="subUsers" class="side-nav-menu side-nav-menu-second-level mb-0">
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="users.php">All Users</a>
                </li>
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="user-edit.php">Add User</a>
                </li>
            </ul>
            <!-- End Users: subUsers -->
        </li>
        <!-- End Users -->

        <!-- Settings -->
        <li class="side-nav-menu-item">
            <a class="side-nav-menu-link media align-items-center" href="month-form-admin.php">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-file"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">Enter monthly Collections</span>
            </a>
        </li>

        <li class="side-nav-menu-item">
            <a class="side-nav-menu-link media align-items-center" href="yearly-targets.php">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-file"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">Submit Yearly Targets</span>
            </a>
        </li>
        <!-- End Settings -->

        <!-- Generate Report -->
        <li class="side-nav-menu-item side-nav-has-menu">
            <a class="side-nav-menu-link media align-items-center" href="#"
               data-target="#subReports">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-file"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">Generate Report</span>
                <span class="side-nav-control-icon d-flex">
            <i class="gd-angle-right side-nav-fadeout-on-closed"></i>
          </span>
                <span class="side-nav__indicator side-nav-fadeout-on-closed"></span>
            </a>

            <!-- Reports: subReports -->
            <ul id="subReports" class="side-nav-menu side-nav-menu-second-level mb-0">
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="monthly-report.html">Monthly Report</a>
                </li>
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="financial-year-report.html">Financial Year Report</a>
                </li>
            </ul>
            <!-- End Reports: subReports -->
        </li>
        <!-- End Generate Report -->

        <!-- Authentication -->
        <li class="side-nav-menu-item side-nav-has-menu">
            <a class="side-nav-menu-link media align-items-center" href="#"
               data-target="#subPages">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-lock"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">Account Logout</span>
                <span class="side-nav-control-icon d-flex">
            <i class="gd-angle-right side-nav-fadeout-on-closed"></i>
          </span>
                <span class="side-nav__indicator side-nav-fadeout-on-closed"></span>
            </a>

            <!-- Pages: subPages -->
            <ul id="subPages" class="side-nav-menu side-nav-menu-second-level mb-0">
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="login.html">Login</a>
                </li>
               
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="password-reset.html">Forgot Password</a>
                </li>
              
            </ul>
            <!-- End Pages: subPages -->
        </li>
        <!-- End Authentication -->

        <!-- Settings -->
        <li class="side-nav-menu-item">
            <a class="side-nav-menu-link media align-items-center" href="edit-profile.php">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-settings"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">My Profile</span>
            </a>
        </li>
        <!-- End Settings -->
    </ul>
</aside>
    <!-- End Sidebar Nav -->
    <div class="content">
        <div class="py-4 px-3 px-md-4">
        <div class="card mb-3 mb-md-4">
                <div class="mb-3 mb-md-4 d-flex justify-content-between">
                     <div class="h3 mb-0">Dashboard</div>

                 </div>

             
                 <div class="row">
                    
                    <div class="col-md-6 col-xl-4 mb-3 mb-xl-4">
                        <!-- Widget -->
                        <div class="card flex-row align-items-center p-3 p-md-4">
                            <div class="icon icon-lg bg-soft-primary rounded-circle mr-3">
                                <i class="gd-bar-chart icon-text d-inline-block text-primary"></i>
                            </div>
                            <div>
                                <h4 class="lh-1 mb-1">75%</h4>
                                <h6 class="mb-0">Month Target</h6>
                            </div>
                            <i class="gd-arrow-up icon-text d-flex text-success ml-auto"></i>
                        </div>
                        <!-- End Widget -->
                    </div>
    
                    <div class="col-md-6 col-xl-4 mb-3 mb-xl-4">
                        <!-- Widget -->
                        <div class="card flex-row align-items-center p-3 p-md-4">
                            <div class="icon icon-lg bg-soft-secondary rounded-circle mr-3">
                                <i class="gd-wallet icon-text d-inline-block text-secondary"></i>
                            </div>
                            <div>
                                <h4 class="lh-1 mb-1">$18,000.00</h4>
                                <h6 class="mb-0">Month Total Collected</h6>
                            </div>
                            <i class="gd-arrow-down icon-text d-flex text-danger ml-auto"></i>
                        </div>
                        <!-- End Widget -->
                    </div>
    
                    <div class="col-md-6 col-xl-4 mb-3 mb-xl-4">
                        <!-- Widget -->
                        <div class="card flex-row align-items-center p-3 p-md-4">
                            <div class="icon icon-lg bg-soft-warning rounded-circle mr-3">
                                <i class="gd-money icon-text d-inline-block text-warning"></i>
                            </div>
                            <div>
                                <h4 class="lh-1 mb-1">$10,000.00</h4>
                                <h6 class="mb-0">Month Balance</h6>
                            </div>
                            <i class="gd-arrow-up icon-text d-flex text-success ml-auto"></i>
                        </div>
                        <!-- End Widget -->
                    </div>
    
                </div>



        
            <div class="container mt-5">
                <h2 class="mb-4" align="center">Monthly Revenue Collection</h2>

                <!-- Search Bar -->
                
                
               <!-- Select Month Form -->
<div class="row mb-3">
    <div class="col-md-4">
        <form method="POST" action="">
            <label for="monthSelect">Select Month</label>
            <select id="monthSelect" name="month_id" class="form-control" onchange="this.form.submit()">
                <option value="">Select Month</option>
                <?php
                // Fetch and display available months
                $month_query = "SELECT id, month_name, year FROM MONTHS";
                $months_result = $conn->query($month_query);
                while ($month = $months_result->fetch_assoc()) {
                    $selected = ($month_id == $month['id']) ? 'selected' : '';
                    echo "<option value='{$month['id']}' {$selected}>{$month['month_name']} {$month['year']}</option>";
                }
                ?>
            </select>
        </form>
    </div>
</div>

<!-- Revenue Collection Table -->
<table class="table text-nowrap mb-0">
    <thead>
        <tr>
            <th class="font-weight-semi-bold border-top-0 py-2">S/N</th>
            <th class="font-weight-semi-bold border-top-0 py-2">RMO Office Name</th>
            <th class="font-weight-semi-bold border-top-0 py-2">Month</th>
            <th class="font-weight-semi-bold border-top-0 py-2">Year</th>
            <th class="font-weight-semi-bold border-top-0 py-2">Target</th>
            <th class="font-weight-semi-bold border-top-0 py-2">Total Collected</th>
            <th class="font-weight-semi-bold border-top-0 py-2">Percentage Balance</th>
            <th class="font-weight-semi-bold border-top-0 py-2">Balance</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Display the fetched data
        if (isset($result) && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td class='py-3'>{$sn}</td>";
                echo "<td class='py-3'>{$row['rmo_office_name']}</td>";
                echo "<td class='py-3'>{$row['month_name']}</td>";
                echo "<td class='py-3'>{$row['year']}</td>";
                echo "<td class='py-3'>TZS " . number_format($row['target'], 2) . "</td>";
                echo "<td class='py-3'>TZS " . number_format($row['total_collected'], 2) . "</td>";
                echo "<td class='py-3'>{$row['percentage_balance']}%</td>";
                echo "<td class='py-3'>TZS " . number_format($row['BALANCE'], 2) . "</td>";
                echo "</tr>";
                $sn++;
            }
        } else {
            echo "<tr><td colspan='8' class='text-center'>Select a month to display data.</td></tr>";
        }
        ?>
    </tbody>
</table>

            
            </div>
          
        </div>

        </div>

        <!-- Footer -->
        <footer class="small p-3 px-md-4 mt-auto">
            <div class="row justify-content-between">
                <div class="col-lg text-center text-lg-right">
                    &copy; 2024 rmo data report system. All Rights Reserved.
                </div>
            </div>
        </footer>
        <!-- End Footer -->
    </div>
</main>

<script src="public/graindashboard/js/graindashboard.js"></script>
<script src="public/graindashboard/js/graindashboard.vendor.js"></script>

<!-- DEMO CHARTS -->
<script src="public/demo/resizeSensor.js"></script>
<script src="public/demo/chartist.js"></script>
<script src="public/demo/chartist-plugin-tooltip.js"></script>
<script src="public/demo/gd.chartist-area.js"></script>
<script src="public/demo/gd.chartist-bar.js"></script>
<script src="public/demo/gd.chartist-donut.js"></script>
<script>
    $.GDCore.components.GDChartistArea.init('.js-area-chart');
    $.GDCore.components.GDChartistBar.init('.js-bar-chart');
    $.GDCore.components.GDChartistDonut.init('.js-donut-chart');
</script>
</body>
</html>
