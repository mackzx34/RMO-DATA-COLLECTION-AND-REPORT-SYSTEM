<?php
// Include database connection
include('config/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $rmo_id = $_POST['office_id'];
    $month_id = $_POST['month_id'];
    $total_collected = $_POST['collected'];

    // Assuming a unique constraint on rmo_id and month_id
    // Adjust the query based on your actual table structure and constraints
    $sql = "INSERT INTO DATA (rmo_id, month_id, total_collected) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE total_collected = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiid", $rmo_id, $month_id, $total_collected,$total_collected);

    if ($stmt->execute()) {
        // Success message
        echo '<div id="successMessage" class="alert alert-success text-center" role="alert">
                Data successfully saved or updated!
              </div>';
    } else {
        // Error message
        echo '<div id="errorMessage" class="alert alert-danger text-center" role="alert">
                Error saving data. Please try again.
              </div>';
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Title -->
    <title>Monthly Collected</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Favicon -->
    <link rel="shortcut icon" href="public/img/favicon.ico">

    <!-- DEMO CHARTS -->
    <link rel="stylesheet" href="public/demo/chartist.css">
    <link rel="stylesheet" href="public/demo/chartist-plugin-tooltip.css">

    <!-- Template -->
    <link rel="stylesheet" href="public/graindashboard/css/graindashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="has-sidebar has-fixed-sidebar-and-header">
<!-- Header -->
<header class="header bg-body">
    <nav class="navbar flex-nowrap p-0">
        <div class="navbar-brand-wrapper d-flex align-items-center col-auto">
            <!-- Logo For Mobile View -->
            <a class="navbar-brand navbar-brand-mobile" href="/">
                <img class="img-fluid w-100" src="public/img/logo-mini.png" alt="Graindashboard">
            </a>
            <!-- End Logo For Mobile View -->

            <!-- Logo For Desktop View -->
            <a class="navbar-brand navbar-brand-desktop" href="/">
               
                <img class="side-nav-hide-on-closed" src="public/img/kalogo.png" style="width: auto; height: 60px;">
            </a>
            <!-- End Logo For Desktop View -->
        </div>

        <div class="header-content col px-md-3">
            <div class="d-flex align-items-center">
                <!-- Side Nav Toggle -->
                <a class="js-side-nav header-invoker d-flex mr-md-2" href="#"
                    data-close-invoker="#sidebarClose"
                    data-target="#sidebar"
                    data-target-wrapper="body">
                    <i class="gd-align-left"></i>
                </a>
                <!-- End Side Nav Toggle -->

                <!-- User Notifications -->
                <div class="dropdown ml-auto">
                    
                </div>
                <!-- End User Notifications -->
                <!-- User Avatar -->
                <div class="dropdown mx-3 dropdown ml-2">
                    <a id="profileMenuInvoker" class="header-complex-invoker" href="#" aria-controls="profileMenu" aria-haspopup="true" aria-expanded="false" data-unfold-event="click" data-unfold-target="#profileMenu" data-unfold-type="css-animation" data-unfold-duration="300" data-unfold-animation-in="fadeIn" data-unfold-animation-out="fadeOut">
        
                        <span class="d-none d-md-block">RMO - User</span>
                        <i class="gd-angle-down d-none d-md-block ml-2"></i>
                    </a>

                    <ul id="profileMenu" class="unfold unfold-user unfold-light unfold-top unfold-centered position-absolute pt-2 pb-1 mt-4 unfold-css-animation unfold-hidden fadeOut" aria-labelledby="profileMenuInvoker" style="animation-duration: 300ms;">
                        <li class="unfold-item">
                            <a class="unfold-link d-flex align-items-center text-nowrap" href="#">
                    <span class="unfold-item-icon mr-3">
                      <i class="gd-user"></i>
                    </span>
                                My Profile
                            </a>
                        </li>
                        <li class="unfold-item unfold-item-has-divider">
                            <a class="unfold-link d-flex align-items-center text-nowrap" href="logout.php">
                    <span class="unfold-item-icon mr-3">
                      <i class="gd-power-off"></i>
                    </span>
                                Sign Out
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- End User Avatar -->
            </div>
        </div>
    </nav>
</header>
<!-- End Header -->

<main class="main">
    <!-- Sidebar Nav -->
    <aside id="sidebar" class="js-custom-scroll side-nav">
    <ul id="sideNav" class="side-nav-menu side-nav-menu-top-level mb-0">
        <!-- Title -->
       
        <!-- End Title -->

        <!-- Dashboard -->
        <li class="side-nav-menu-item active">
            <a class="side-nav-menu-link media align-items-center" href="user_dashboard.php">
              <span class="side-nav-menu-icon d-flex mr-3">
                <i class="gd-dashboard"></i>
              </span>
                <span class="side-nav-fadeout-on-closed media-body">Dashboard</span>
            </a>
        </li>
        <!-- End Dashboard -->

        <!-- Generate Report -->
        <li class="side-nav-menu-item side-nav-has-menu">
            <a class="side-nav-menu-link media align-items-center" href="#"
               data-target="#subReports">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-file"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">Generate Report</span>
                <span class="side-nav-control-icon d-flex">
            <i class="gd-angle-right side-nav-fadeout-on-closed"></i>
          </span>
                <span class="side-nav__indicator side-nav-fadeout-on-closed"></span>
            </a>

            <!-- Reports: subReports -->
            <ul id="subReports" class="side-nav-menu side-nav-menu-second-level mb-0">
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="monthly-report.html">Monthly Report</a>
                </li>
                <li class="side-nav-menu-item">
                    <a class="side-nav-menu-link" href="financial-year-report.html">Financial Year Report</a>
                </li>
            </ul>
            <!-- End Reports: subReports -->
        </li>
        <!-- End Generate Report -->

        <!-- Authentication -->
        
        <!-- End Authentication -->

        <li class="side-nav-menu-item">
            <a class="side-nav-menu-link media align-items-center" href="month-form-user.php">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-file"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">Enter monthly Collections</span>
            </a>
        </li>

        <!-- Settings -->
        <li class="side-nav-menu-item">
            <a class="side-nav-menu-link media align-items-center" href="settings.html">
          <span class="side-nav-menu-icon d-flex mr-3">
            <i class="gd-settings"></i>
          </span>
                <span class="side-nav-fadeout-on-closed media-body">Profile Settings</span>
            </a>
        </li>
        <!-- End Settings -->


        <li class="side-nav-menu-item">
         <a class="side-nav-menu-link media align-items-center" href="logout.php">
      <span class="side-nav-menu-icon d-flex mr-3">
        <i class="fas fa-sign-out-alt"></i> <!-- FontAwesome icon for Logout -->
      </span>
        <span class="side-nav-fadeout-on-closed media-body"> Logout</span>
       </a>
      </li>


        
    </ul>
</aside>
    <!-- End Sidebar Nav -->

    <div class="content">
        <div class="py-4 px-3 px-md-4">
            <div class="card mb-3 mb-md-4">

                <div class="card-body">
                    
                
                   <!-- Display messages -->
<?php if ($message): ?>
    <div class="alert alert-<?php echo $success ? 'success' : 'danger'; ?>" id="messageAlert">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <script>
        // Hide the message after 3 seconds (3000 milliseconds)
        setTimeout(function() {
            var messageAlert = document.getElementById('messageAlert');
            if (messageAlert) {
                messageAlert.style.display = 'none';
            }
        }, 3000);
    </script>
<?php endif; ?>

<!-- Form -->
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8">
            <h2 class="text-center my-4">Enter Monthly Revenue Collected</h2>
            <form action="month-form-user.php" method="post">
                <div class="form-row">
                    <div class="form-group col-12 col-md-5">
                        <label for="office">RMO Office Name</label>
                        <select id="office" name="office_id" class="form-control" required>
                            <option value="">Select Office</option>
                            <?php
                            // Fetch data from RMO_OFFICE table
                            $query = "SELECT id, office_name FROM RMO_OFFICE";
                            $result = mysqli_query($conn, $query);
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '<option value="'.$row['id'].'">'.$row['office_name'].'</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group col-12 col-md-5 offset-md-2">
                        <label for="month">Month and Year</label>
                        <select id="month" name="month_id" class="form-control" required>
                            <option value="">Select Month and Year</option>
                            <?php
                            // Fetch data from MONTHS table
                            $query = "SELECT id, month_name, year FROM MONTHS";
                            $result = mysqli_query($conn, $query);
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '<option value="'.$row['id'].'">'.$row['month_name'].' '.$row['year'].'</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-12 col-md-10">
                        <label for="collected">Total Collected in Tsh</label>
                        <input type="text" class="form-control" id="collected" name="collected" placeholder="Total Collected in Tsh" required>
                    </div>
                </div>
                
                <div class="form-row justify-content-center mt-4">
                    <button type="reset" class="btn btn-secondary mx-2">Reset</button>
                    <button type="submit" class="btn btn-primary mx-2">Submit</button>
                    <button type="button" class="btn btn-danger mx-2" onclick="window.location.href='month-form-user.php'">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- End Form -->



                </div>
                
            </div>
        </div>
    </div>
</main>

<script src="public/graindashboard/js/graindashboard.js"></script>
<script src="public/graindashboard/js/graindashboard.vendor.js"></script>

<!-- Custom JavaScript to hide the alert after 3 seconds -->
<!-- JavaScript to hide the success message after 5 seconds -->
<script>
    setTimeout(function() {
        var successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }, 5000); // 5000ms = 5 seconds
</script>

</body>
</html>
