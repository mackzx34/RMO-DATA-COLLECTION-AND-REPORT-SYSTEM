<?php
// Include database connection
include 'config/config.php';

// Start the session
session_start();

// Fetch user data
$sql = "SELECT id, fname, lname, username, email, mobile, position, RMO_OFFICE_NAME, roleid, isActive FROM tbl_users";
$result = $conn->query($sql);

// Define roles
$roles = [
    1 => 'Admin',
    2 => 'User'
];

// Define status
$status = [
    1 => 'Active',
    0 => 'Inactive'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Title -->
    <title>User Management</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Favicon -->
    <link rel="shortcut icon" href="public/img/favicon.ico">

    <!-- DEMO CHARTS -->
    <link rel="stylesheet" href="public/demo/chartist.css">
    <link rel="stylesheet" href="public/demo/chartist-plugin-tooltip.css">

    <!-- Template -->
    <link rel="stylesheet" href="public/graindashboard/css/graindashboard.css">
</head>

<body class="has-sidebar has-fixed-sidebar-and-header">
<!-- Header -->
<header class="header bg-body">
    <nav class="navbar flex-nowrap p-0">
        <div class="navbar-brand-wrapper d-flex align-items-center col-auto">
            <!-- Logo For Mobile View -->
            <a class="navbar-brand navbar-brand-mobile" href="/">
                <img class="img-fluid w-100" src="public/img/logo-mini.png" alt="Graindashboard">
            </a>
            <!-- End Logo For Mobile View -->

            <!-- Logo For Desktop View -->
            <a class="navbar-brand navbar-brand-desktop" href="/">
                <img class="side-nav-hide-on-closed" src="public/img/kalogo.png" alt="R" style="width: auto; height: 60px;">
            </a>
            <!-- End Logo For Desktop View -->
        </div>

        <div class="header-content col px-md-3">
            <div class="d-flex align-items-center">
                <!-- Side Nav Toggle -->
                <a class="js-side-nav header-invoker d-flex mr-md-2" href="#"
                    data-close-invoker="#sidebarClose"
                    data-target="#sidebar"
                    data-target-wrapper="body">
                    <i class="gd-align-left"></i>
                </a>
                <!-- End Side Nav Toggle -->

                <!-- User Notifications -->
                <div class="dropdown ml-auto">
                    
                </div>
                <!-- End User Notifications -->
                <!-- User Avatar -->
                <div class="dropdown mx-3 dropdown ml-2">
                    <a id="profileMenuInvoker" class="header-complex-invoker" href="#" aria-controls="profileMenu" aria-haspopup="true" aria-expanded="false" data-unfold-event="click" data-unfold-target="#profileMenu" data-unfold-type="css-animation" data-unfold-duration="300" data-unfold-animation-in="fadeIn" data-unfold-animation-out="fadeOut">
                    
                        <span class="d-none d-md-block">RMO - Admin</span>
                        <i class="gd-angle-down d-none d-md-block ml-2"></i>
                    </a>

                    <ul id="profileMenu" class="unfold unfold-user unfold-light unfold-top unfold-centered position-absolute pt-2 pb-1 mt-4 unfold-css-animation unfold-hidden fadeOut" aria-labelledby="profileMenuInvoker" style="animation-duration: 300ms;">
                        <li class="unfold-item">
                            <a class="unfold-link d-flex align-items-center text-nowrap" href="#">
                                <span class="unfold-item-icon mr-3">
                                  <i class="gd-user"></i>
                                </span>
                                My Profile
                            </a>
                        </li>
                        <li class="unfold-item unfold-item-has-divider">
                            <a class="unfold-link d-flex align-items-center text-nowrap" href="logout.php">
                                <span class="unfold-item-icon mr-3">
                                  <i class="gd-power-off"></i>
                                </span>
                                Sign Out
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- End User Avatar -->
            </div>
        </div>
    </nav>
</header>
<!-- End Header -->

<main class="main">
    <!-- Sidebar Nav -->
    <aside id="sidebar" class="js-custom-scroll side-nav">
        <ul id="sideNav" class="side-nav-menu side-nav-menu-top-level mb-0">
            <!-- Title -->
            <li class="sidebar-heading h6">Dashboard</li>
            <!-- End Title -->

            <!-- Dashboard -->
            <li class="side-nav-menu-item active">
                <a class="side-nav-menu-link media align-items-center" href="admin_dashboard.php">
                  <span class="side-nav-menu-icon d-flex mr-3">
                    <i class="gd-dashboard"></i>
                  </span>
                    <span class="side-nav-fadeout-on-closed media-body">Dashboard</span>
                </a>
            </li>
            <!-- End Dashboard -->

            <!-- Title -->
            <li class="sidebar-heading h6">Examples</li>
            <!-- End Title -->

            <!-- Users -->
            <li class="side-nav-menu-item side-nav-has-menu">
                <a class="side-nav-menu-link media align-items-center" href="#"
                   data-target="#subUsers">
                  <span class="side-nav-menu-icon d-flex mr-3">
                    <i class="gd-user"></i>
                  </span>
                    <span class="side-nav-fadeout-on-closed media-body">Users</span>
                    <span class="side-nav-control-icon d-flex">
                  <i class="gd-angle-right side-nav-fadeout-on-closed"></i>
                </span>
                    <span class="side-nav__indicator side-nav-fadeout-on-closed"></span>
                </a>

                <!-- Users: subUsers -->
                <ul id="subUsers" class="side-nav-menu side-nav-menu-second-level mb-0">
                    <li class="side-nav-menu-item">
                        <a class="side-nav-menu-link" href="users.php">All Users</a>
                    </li>
                    <li class="side-nav-menu-item">
                        <a class="side-nav-menu-link" href="user-edit.php">Add User</a>
                    </li>
                </ul>
                <!-- End Users: subUsers -->
            </li>
            <!-- End Users -->

            <!-- Generate Report -->
            <li class="side-nav-menu-item side-nav-has-menu">
                <a class="side-nav-menu-link media align-items-center" href="#"
                   data-target="#subReports">
              <span class="side-nav-menu-icon d-flex mr-3">
                <i class="gd-file"></i>
              </span>
                    <span class="side-nav-fadeout-on-closed media-body">Generate Report</span>
                    <span class="side-nav-control-icon d-flex">
                <i class="gd-angle-right side-nav-fadeout-on-closed"></i>
              </span>
                    <span class="side-nav__indicator side-nav-fadeout-on-closed"></span>
                </a>

                <!-- Reports: subReports -->
                <ul id="subReports" class="side-nav-menu side-nav-menu-second-level mb-0">
                    <li class="side-nav-menu-item">
                        <a class="side-nav-menu-link" href="monthly-report.html">Monthly Report</a>
                    </li>
                    <li class="side-nav-menu-item">
                        <a class="side-nav-menu-link" href="financial-year-report.html">Financial Year Report</a>
                    </li>
                </ul>
                <!-- End Reports: subReports -->
            </li>
            <!-- End Generate Report -->

            <!-- Authentication -->
            <li class="side-nav-menu-item side-nav-has-menu">
                <a class="side-nav-menu-link media align-items-center" href="#"
                   data-target="#subPages">
              <span class="side-nav-menu-icon d-flex mr-3">
                <i class="gd-lock"></i>
              </span>
                    <span class="side-nav-fadeout-on-closed media-body">Authentication</span>
                    <span class="side-nav-control-icon d-flex">
                <i class="gd-angle-right side-nav-fadeout-on-closed"></i>
              </span>
                    <span class="side-nav__indicator side-nav-fadeout-on-closed"></span>
                </a>

                <!-- Pages: subPages -->
                <ul id="subPages" class="side-nav-menu side-nav-menu-second-level mb-0">
                    <li class="side-nav-menu-item">
                        <a class="side-nav-menu-link" href="login.html">Login</a>
                    </li>
                    <li class="side-nav-menu-item">
                        <a class="side-nav-menu-link" href="password-reset.html">Forgot Password</a>
                    </li>
                </ul>
                                <!-- End Pages: subPages -->
            </li>
            <!-- End Authentication -->

            <!-- Settings -->
            <li class="side-nav-menu-item">
                <a class="side-nav-menu-link media align-items-center" href="settings.html">
              <span class="side-nav-menu-icon d-flex mr-3">
                <i class="gd-settings"></i>
              </span>
                    <span class="side-nav-fadeout-on-closed media-body">Settings</span>
                </a>
            </li>
            <!-- End Settings -->
        </ul>
    </aside>
    <!-- End Sidebar Nav -->

    <!-- Users -->
    <div class="py-4 px-3">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Users</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive-xl">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col" class="py-3">#</th>
                                <th scope="col" class="py-3">First Name</th>
                                <th scope="col" class="py-3">Last Name</th>
                                <th scope="col" class="py-3">Username</th>
                                <th scope="col" class="py-3">Email</th>
                                <th scope="col" class="py-3">Mobile</th>
                                <th scope="col" class="py-3">Position</th>
                                <th scope="col" class="py-3">Regional Office</th>
                                <th scope="col" class="py-3">Role</th>
                                <th scope="col" class="py-3">Status</th>
                                <th scope="col" class="py-3">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $counter = 1; // Initialize the counter
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<tr>';
                                    echo '<td class="py-3">' . $counter++ . '</td>'; // Use counter instead of id
                                    echo '<td class="py-3">' . htmlspecialchars($row['fname']) . '</td>';
                                    echo '<td class="py-3">' . htmlspecialchars($row['lname']) . '</td>';
                                    echo '<td class="py-3">' . htmlspecialchars($row['username']) . '</td>';
                                    echo '<td class="py-3">' . htmlspecialchars($row['email']) . '</td>';
                                    echo '<td class="py-3">' . htmlspecialchars($row['mobile']) . '</td>';
                                    echo '<td class="py-3">' . htmlspecialchars($row['position']) . '</td>';
                                    echo '<td class="py-3">' . htmlspecialchars($row['RMO_OFFICE_NAME']) . '</td>';
                                    echo '<td class="py-3">' . $roles[$row['roleid']] . '</td>';
                                    echo '<td class="py-3">' . $status[$row['isActive']] . '</td>';
                                    echo '<td class="py-3">
                                            <a href="user-edit.php?id=' . $row['id'] . '" class="btn btn-sm btn-primary">
                                                Edit
                                            </a>
                                            <a href="user-action.php?id=' . $row['id'] . '&action=' . ($row['isActive'] ? 'deactivate' : 'activate') . '" class="btn btn-sm btn-secondary" onclick="return confirm(\'Are you sure you want to ' . ($row['isActive'] ? 'deactivate' : 'activate') . ' this user?\');">
                                                ' . ($row['isActive'] ? 'Inactivate' : 'Activate') . '
                                            </a>
                                          </td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="11" class="py-3 text-center">No users found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- End Users -->
</main>
<!-- End Main Content -->

<!-- Footer -->
<footer class="footer bg-body">
    <div class="container text-center">
        <p class="mb-0">&copy; 2024 Your Company. All rights reserved.</p>
    </div>
</footer>
<!-- End Footer -->

<!-- Scripts -->
<script src="public/vendor/jquery/jquery.min.js"></script>
<script src="public/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<script src="public/vendor/unfold/unfold.min.js"></script>
<script src="public/vendor/hs-megamenu/hs.megamenu.min.js"></script>
<script src="public/vendor/hs-toggle-switch/hs.toggle-switch.min.js"></script>
<script src="public/graindashboard/js/graindashboard.js"></script>
<script src="public/graindashboard/js/graindashboard.vendor.js"></script>

</body>
</html>

