<?php
session_start(); // Start the session

// Database credentials
$servername = "localhost"; // Replace with your database server
$username = "admin_madini"; // Replace with your database username
$password = "password12345"; // Replace with your database password
$dbname = "RMO_REPORT"; // Replace with your database name

// Create a new database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize login error variable
$login_error = '';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email and password from POST request
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $remember = isset($_POST['remember']); // Check if 'Remember Me' is checked

    // Prepare a statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, fname, lname, username, position, email, roleid, isActive, password FROM tbl_users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Check if the email exists
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $fname, $lname, $username, $position, $email, $roleid, $isActive, $hashed_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashed_password)) {
            // Check if the user is active
            if ($isActive) {
                // Set session variables
                $_SESSION['user_id'] = $id;
                $_SESSION['fname'] = $fname;
                $_SESSION['lname'] = $lname;
                $_SESSION['username'] = $username;
                $_SESSION['roleid'] = $roleid;

                // Handle "Remember Me" functionality
                if ($remember) {
                    // Set a cookie to remember the user
                    $cookie_expiration = time() + (86400 * 30); // 30 days
                    $cookie_value = $id . '|' . $roleid; // Combine user ID and role ID

                    // Hash the cookie value for security
                    $cookie_hash = hash('sha256', $cookie_value);

                    // Set a secure, HTTP-only cookie
                    setcookie('remember_me', $cookie_hash, $cookie_expiration, '/', '', true, true);

                    // Store the actual value in the database
                    $stmt = $conn->prepare("UPDATE tbl_users SET remember_me = ? WHERE id = ?");
                    $stmt->bind_param("si", $cookie_hash, $id);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    // Delete the cookie if "Remember Me" is not checked
                    if (isset($_COOKIE['remember_me'])) {
                        setcookie('remember_me', '', time() - 3600, '/');
                    }
                }

                // Redirect based on role
                if ($roleid == 1) { // Assuming 1 is the role ID for admin
                    header("Location: admin_dashboard.php"); // Admin dashboard
                } else {
                    header("Location: user_dashboard.php"); // Normal user dashboard
                }
                exit();
            } else {
                $login_error = "Account is inactive. Please contact support.";
            }
        } else {
            $login_error = "Invalid password.";
        }
    } else {
        $login_error = "No account found with that email.";
    }

    $stmt->close();
    $conn->close();

    // If login fails, clear the cache and redirect to login page with an error message
    if (!empty($login_error)) {
        // Clear output buffer and disable caching
        if (ob_get_length()) ob_end_clean();
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Location: login.php?error=" . urlencode($login_error));
        exit();
    }
}
?>
